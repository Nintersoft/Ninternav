Ninternav
=========

Navegador Nintersoft para Android
 Repositório oficial do Ninternav (Navegador oficial Nintersoft para Android)
 
Siga as Lincenças de código aberto Nintersoft para este repositório. Você poderá clonar e modificar os códigos deste repositório da forma que você quiser, mas deverá manter o README original. Por favor, contamos com sua colaboração.

Atenciosamente,
Equipe Nintersoft.

=========
